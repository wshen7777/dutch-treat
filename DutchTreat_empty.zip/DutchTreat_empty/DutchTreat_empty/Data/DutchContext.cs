﻿using System;
using DutchTreat_empty.Data.Entities;
using Microsoft.EntityFrameworkCore;

namespace DutchTreat_empty.Data
{
	public class DutchContext : DbContext
	{
		public DbSet<Product> Products { get; set; }
		public DbSet<Order> Orders {get; set;}
        private readonly IConfiguration _config;

        public DutchContext(DbContextOptions<DutchContext> options)
            : base(options)
        {
          
        }
    }
}

