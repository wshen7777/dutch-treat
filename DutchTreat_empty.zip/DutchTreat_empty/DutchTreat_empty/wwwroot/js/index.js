﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.
//$ is allias of jquery
$(document).ready(function () {
    var theForm = $('#theForm');
    theForm.hide();

    var button = $("#buyButt")
    button.on("click", function () {
        console.log("Buying item")
    })

    var productInfo = $(".product-props li");
    productInfo.on('click', function () {

    });

    var loginToggle = $("#loginToggle");
    var popupForm = $(".popup-form");

    loginToggle.on('click', function () {
        //can have slideToggle / fadeToggle
        popupForm.toggle(1000)
    });
});