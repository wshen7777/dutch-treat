﻿using Microsoft.AspNetCore.Mvc;
using System;
using Microsoft.Extensions.DependencyInjection;
using DutchTreat_empty.Services;
using DutchTreat_empty.Data;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);
//builder.Configuration.Sources.Clear();
//builder.Configuration.SetBasePath(Directory.GetCurrentDirectory())
//    .AddJsonFile("config.json")
//    .AddEnvironmentVariables();
var connectionString = builder.Configuration.GetConnectionString("DutchContextDb");

//add database context
builder.Services.AddDbContextPool<DutchContext>(cfg =>
{
    cfg.UseMySql(connectionString, ServerVersion.AutoDetect(connectionString));
});

builder.Services.AddTransient<IMailService, NullMailService>();
builder.Services.AddControllersWithViews()
.AddRazorRuntimeCompilation();
builder.Services.AddRazorPages();

var app = builder.Build();

//for developer handle error
if (app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();
}
else
{
    app.UseExceptionHandler("/error");
}

app.UseStaticFiles();
app.UseRouting();
app.MapRazorPages();
app.MapControllerRoute(
    name: "Default",
    pattern: "{controller=App}/{action=Index}/{id?}");

app.Run();
