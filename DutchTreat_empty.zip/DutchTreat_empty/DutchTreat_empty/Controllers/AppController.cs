﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DutchTreat_empty.ViewModels;
using DutchTreat_empty.Services;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace DutchTreat_empty.Controllers
{
    public class AppController : Controller
    {
        private readonly IMailService _mailService;
        // GET: /<controller>/
        public AppController(IMailService mailService)
        {
            _mailService = mailService;
        }

        public IActionResult Index()
        {
            //throw new InvalidProgramException("error");
            return View();
        }
        //when we get from 'contact'
        [HttpGet("contact")]
        public IActionResult Contact()
        {
            ViewBag.Title = "Contact Us";
            return View();
        }
        //when we post to 'contact'
        [HttpPost("contact")]
        public IActionResult Contact(ContactViewModel model)
        {
            if (ModelState.IsValid)
            {
                //send email
                _mailService.SendMessage("cws_0712@hotmail.com", model.Subject, $"From {model.Name} - {model.Email}, Message: {model.Message}");
                ViewBag.UserMessage = "Email Sent";
                ModelState.Clear();
            }
            else
            {
                //show error

            }
            ViewBag.Title = "Contact Us";
            return View();
        }

        [HttpGet("about")]
        public IActionResult About()
        {
            ViewBag.Title = "About Us";
            return View();
        }
    }
}

